package com.divyasuman.mycredibleinfo

import android.content.Intent
import android.net.Uri
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val textView: ImageButton = findViewById(R.id.twitter) as ImageButton
        textView.setOnClickListener {
            val uris = Uri.parse("https://twitter.com/login")
            val intents = Intent(Intent.ACTION_VIEW, uris)
            startActivity(intent)
        }
    }
}
