package com.divyasuman.mycredibleinfo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Main_Activity_5 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main__5)
    }
}
